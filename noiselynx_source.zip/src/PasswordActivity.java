import android.os.Bundle;

import com.actionbarsherlock.app.SherlockActivity;

public class PasswordActivity extends SherlockActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

}
