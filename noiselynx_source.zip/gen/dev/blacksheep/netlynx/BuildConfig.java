/** Automatically generated file. DO NOT MODIFY */
package dev.blacksheep.netlynx;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}